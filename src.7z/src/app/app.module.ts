import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
// import { HttpClient } from '@angular/common/http';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { LoginComponent } from './login/login.component';
import {MasterPageComponent} from './MasterPage/masterPage.component';
import { from } from 'rxjs';
import {TournamentComponent} from './Tournament/tournament.component';
import {VenuesService} from './Services/venues.service';
import {Step2CreateTournamentComponent} from './Step2CreateTournament/step2CreateTournament.component';

import { TennisDataService  } from './InMemoryWebAPIServices/tennis-data.service';
import { HttpClientModule } from '@angular/common/http';
import { environment } from '../environments/environment.prod';
import { HttpClientInMemoryWebApiModule } from 'angular-in-memory-web-api';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { MatchComponent } from './Match/match.component';


@NgModule({
  declarations: [

    //Only the components
    AppComponent,
    LoginComponent,
    MasterPageComponent,
    TournamentComponent,
    Step2CreateTournamentComponent,
    MatchComponent,
    

  ],
  imports: [
    //import all the modules
    BrowserModule,
    AppRoutingModule,
    HttpClientModule,
    FormsModule,
    ReactiveFormsModule,
    environment.production ? HttpClientInMemoryWebApiModule.forRoot(TennisDataService) : [],
    
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
