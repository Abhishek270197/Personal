import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl, Validators, ReactiveFormsModule } from '@angular/forms'
import { Router } from '@angular/router';
import { UserAccountService } from '../Services/user-account.service';
import { User } from '../Models/user';


@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.scss']
})
export class LoginComponent implements OnInit
{
  loginForm: FormGroup;
  
  

  constructor(private userAccountService: UserAccountService, private router: Router)
  {
    this.loginForm = new FormGroup(
      {
        username: new FormControl(null),
        password: new FormControl(null)
      });
  }

  ngOnInit()
  {
  }

  onLoginClick()
  {
    
    
    this.userAccountService.authenticate(this.loginForm.value.username, this.loginForm.value.password).subscribe((response)=>
    {
     
     
      if (response != null && response.length>0)
      {
        console.log(response);
        this.userAccountService.currentUser = new User(this.loginForm.value.username, response[0].password);
        // this.userAccountService.currentUserType = "User";
        // this.userAccountService.isLoggedIn=true;
        this.router.navigate(['/tournament' ]);
      }
      else{
        alert("Invalid Username or Password");
      }
    }, (error) =>
      {
        console.log(error);
      

    });

  }
}
