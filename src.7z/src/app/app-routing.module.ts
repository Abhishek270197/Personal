import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { LoginComponent } from './login/login.component';
import {MasterPageComponent} from './MasterPage/masterPage.component'
import {TournamentComponent} from './Tournament/tournament.component'
import {Step2CreateTournamentComponent} from './Step2CreateTournament/step2CreateTournament.component'
import { MatchComponent } from './Match/match.component';



const routes: Routes = [
  { path: "", redirectTo: "masterPage", pathMatch: "full" },
  { path: "login", component: LoginComponent },
  { path: "masterPage", component: MasterPageComponent },
  { path: "tournament", component:TournamentComponent },
  { path: "step2CreateTournament/:id", component:Step2CreateTournamentComponent },
  { path: "match", component:MatchComponent },


];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
