import {Injectable} from '@angular/core';
import {HttpClient} from '@angular/common/http';
import {Observable} from 'rxjs';
import {Player} from '../Models/player';



@Injectable({
    providedIn:"root"
})
export class PlayersService{

constructor(private httpClient: HttpClient){

}
AddPlayer(player : Player):Observable<boolean>
{
    player.playerID = this.uuidv4();
    return this.httpClient.post<boolean>(`/api/players`,player);

}
UpdatePlayer(player : Player):Observable<boolean>{
    return this.httpClient.put<boolean>(`/api/players`,player);
}

DeletePlayer(playerID: string, id: number): Observable<boolean>
{
    return this.httpClient.delete<boolean>(`/api/players/${id}`);
}

GetAllPlayers(): Observable<Player[]>
{
    return this.httpClient.get<Player[]>(`/api/players`);
}

GetPlayerByID(ID: number): Observable<Player>
{
  return this.httpClient.get<Player>(`/api/players?id=${ID}`);
}

GetPlayerByPlayerID(playerID: number): Observable<Player>
{
  return this.httpClient.get<Player>(`/api/players?playerID=${playerID}`);
}


uuidv4()  //uuid generator
{
  return 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, function (c)
  {
    var r = Math.random() * 16 | 0, v = c == 'x' ? r : (r & 0x3 | 0x8);
    return v.toString(16);
  });
}

}
