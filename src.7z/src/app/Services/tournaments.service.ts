import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { Tournament } from '../Models/tournament';


@Injectable({
  providedIn: 'root'
})
export class TournamentsService
{
  constructor(private httpClient: HttpClient)
  {
  }

  AddTournament(tournament: Tournament): Observable<boolean>
  {
    
    tournament.tournamentID = this.uuidv4();
    return this.httpClient.post<boolean>(`/api/tournaments`, tournament);
  }

  UpdateTournament(tournament: Tournament): Observable<boolean>
  {
    
    return this.httpClient.put<boolean>(`/api/tournaments`, tournament);
  }

  DeleteTournament(TournamentID: string, id: number): Observable<boolean>
  {
    return this.httpClient.delete<boolean>(`/api/tournaments/${id}`);
  }

  GetAllTournament(): Observable<Tournament[]>
  {
    return this.httpClient.get<Tournament[]>(`/api/tournaments`);
  }

  GetTournamentByID(ID: number): Observable<Tournament>
  {
    return this.httpClient.get<Tournament>(`/api/tournaments?id=${ID}`);
  }

  GetTournamentByTournamentID(TournamentID: string): Observable<Tournament>
  {
    return this.httpClient.get<Tournament>(`/api/tournaments?tournamentID=${TournamentID}`);
  }
  

  
  uuidv4()
  {
    return 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, function (c)
    {
      var r = Math.random() * 16 | 0, v = c == 'x' ? r : (r & 0x3 | 0x8);
      return v.toString(16);
    });
  }
}
