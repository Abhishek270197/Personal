import {Component, OnInit} from '@angular/core';
import { FormGroup, FormControl } from '@angular/forms';
import { Router } from '@angular/router';
import {Tournament} from '../Models/tournament'
import {Match} from '../Models/match'
import { TennisDataService } from 'src/app/InMemoryWebAPIServices/tennis-data.service';
import {Player} from '../Models/player';
import {PlayersService} from '../Services/players.service';
import { MatchesService } from 'src/app/Services/matches.service';
import {ActivatedRoute} from'@angular/router';
import {TournamentsService} from '../Services/tournaments.service'
import { rendererTypeName } from '@angular/compiler';

@Component({
    selector: 'app-step2CreateTournament',
    templateUrl: './step2CreateTournament.component.html',
    styleUrls: ['./step2CreateTournament.component.scss']

})
export class Step2CreateTournamentComponent extends TennisDataService implements OnInit
{

    players: Player[]=[];
    matches: Match[]=[];
    temp: Player[]=[];
    disable : boolean = false;
    step_2 : boolean = true;
    step_3 : boolean = false;
    disabledReason : number;
    a:number[]=[];
    ta:number=0;
    b:number[]=[];
    i:number;
    j:number;
    matchesPlayers:Player[]=[];
    l:number[] = [];
    count:number=0;
    p1:Player = new Player(
       0,
       null,
        null,
        null,
         null,
        0,
         null,
    );

    id: number = -1;
    tournament: Tournament = {
        id:0,
    tournamentID : "",
    tournamentName : "",
    venueID : "",
    startDOT : "",
    endDOT : "",
    winnerID : "",
    runnerUpID : "",
    playersCount : 0,
    matchCount : 0,
    } ;
    playCount : number = 0;
    selected:any;
    colorApply:boolean[]=[];
    
    constructor(private playersService:PlayersService, private matchesService:MatchesService , private route:ActivatedRoute, private tournamentservice: TournamentsService){
        super();
    }
    
    
    
    
    
    ngOnInit(){  
        this.route.paramMap.subscribe(params=>{
         this.id = +params.get('id');
      //   console.log(this.id);
        }, (error)=>{console.log(error);});

        this.tournamentservice.GetTournamentByID(this.id).subscribe(response1=>{
            this.tournament = response1[0];
        
        //    console.log("2nd page")
          
          //  console.log(this.tournament);
       

        

        this.playersService.GetAllPlayers().subscribe((response)=>{
        //    console.log(response);
            this.players = response;
           var length=response.length;
           for( this.i=0;this.i<length;this.i++){
               this.a.push(-1);
           }
           for( this.i=0; this.i<length;this.i++){
            this.colorApply.push(false);
        }
        },
            (error)=>{
            console.log(error);
              
        });
    }, (error)=>{console.log(error);});
        
    }

    
       
    

    

    onbuttonClick(index:number) {
       
        
        this.disabledReason = index;
       
        this.SelectedPlayers(this.disabledReason)
     //   console.log(this.a);
    //    console.log(this.colorApply);
        if(this.colorApply[index]==false)
        this.colorApply[index]=true;
        else
        this.colorApply[index]=false;

    //    console.log(this.colorApply);
      }


      isActive(index){
          if(this.colorApply[index]==true){
       //       console.log(this.colorApply[index]==true);
          return {'highlight' : true};}
          else
          return false;
      }


 SelectedPlayers(value:number){
 
     
for(this.i=0;this.i<this.a.length;this.i++){
    if(this.a.indexOf(value)!=-1){
        this.a[value]=-1;
        break;
    }
    
    
    if(this.a[this.i]==-1){
        this.a[value]=value;
        break;
    }
   
    }
    this.playCount=0;
    for (this.j=0;this.j<this.a.length;this.j++){
        
        if(this.a[this.j]!=-1){
            this.playCount++;
            
        }
    }
  //  console.log(this.playCount);
    
   // console.log(this.tournament.playersCount);
    if(this.playCount==this.tournament.playersCount){
        this.disable = true;
    }
    else{
        this.disable = false;
    }

}

  async createMatches(){
       
    for(this.ta=0;this.ta<this.a.length;this.ta++){
       
        
         if(this.a[this.ta]!=-1)
         {  

            await  this.playersService.GetPlayerByID(this.ta+1).subscribe((response)=>{
    
           this.p1 = response[0];
           //console.log(this.p1);
            
           //console.log(this.mp);
           //console.log(this.mp.length);
            //this.count++;
            
        },
        (error)=>{console.log(error);},
        ()  =>  {
        
         this.matchesPlayers.push(this.p1);
         if(this.matchesPlayers.length==this.tournament.playersCount)
         {
  for(pa=0;pa<(this.tournament.playersCount)/2;pa++){
       
        let matchfor : Match = {
            id : 0,
            tournamentID : "",
            typeOfMatch :"",
            scoreCard:"",
            playerOneID:"",
            playerTwoID:"",
            matchWinnerID:"",
            dOM:"",
            matchID:""

        };
        
        this.matchesService.GetAllMatches().subscribe((response)=>{
            matchfor.id = response.length+1;
        });
        matchfor.tournamentID = this.tournament.tournamentID.toString();
        matchfor.typeOfMatch = "1st Round";
        matchfor.scoreCard = "Yet to decide";
       
        matchfor.playerOneID = this.matchesPlayers[pa].playerID;
        matchfor.dOM = this.tournament.startDOT;
        
        matchfor.playerTwoID = this.matchesPlayers[this.matchesPlayers.length-pa-1].playerID;
        matchfor.matchWinnerID = "Match not played yet";
        this.matchesService.AddMatch(matchfor).subscribe((addResponse)=>
        {
            console.log(addResponse);
        },
        (error) =>
        {
          console.log(error);
        
        });
        
        this.matches.push(matchfor);
        console.log(2,this.matches);
        
    }
         }
        
       
        }
        
        
        );
       }


         
     }

     console.log(2,this.matchesPlayers)
    

    this.step_2=false;
    this.step_3 = true;
    let pa:number;
    console.log(this.tournament);

    let mSet : Match[]=[];
    console.log(this.tournament.tournamentID);
    this.matchesService.GetAllMatches().subscribe((response)=>{
        console.log(response);
        for(pa = 0;pa<response.length;pa++){
        if (this.tournament.tournamentID==response[pa].tournamentID){
        mSet.push(response[pa]);
        console.log(mSet);
        console.log(1,response);
        }}
    });




  
   
   

    // let nop=this.mp.length;

}


 

}



