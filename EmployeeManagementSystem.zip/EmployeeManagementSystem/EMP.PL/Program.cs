﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using EMS.Entity;
using EMS.Exception;
using EMS.BL;

namespace EMP.PL
{
    class Program
    {
        public static void AddEmployee()
        {
            Employee emp = new Employee();

            try
            {
                Console.Write("Enter Employee ID : ");
                emp.ID = Convert.ToInt32(Console.ReadLine());
                Console.Write("Enter Employee Name : ");
                emp.Name = Console.ReadLine();
                Console.Write("Enter Date of Joining : ");
                emp.DOJ = Convert.ToDateTime(Console.ReadLine());
                Console.Write("Enter Employee Salary : ");
                emp.Salary = Convert.ToDouble(Console.ReadLine());

                bool empAdded = EmployeeValidation.AddEmployee(emp);

                if (empAdded)
                {
                    Console.WriteLine("Employee Added Successfully");
                }
                else
                    throw new EmployeeException("Employee Details not Added");

            }
            catch (EmployeeException ex)
            {
                Console.WriteLine(ex.Message);
            }
            catch (SystemException ex)
            {
                Console.WriteLine(ex.Message);
            }
        }

        public static void UpdateEmployee()
        {
            Employee emp = new Employee();

            try
            {
                Console.Write("Enter Employee ID to be Updated : ");
                emp.ID = Convert.ToInt32(Console.ReadLine());
                Console.Write("Enter Employee Name to be Updated : ");
                emp.Name = Console.ReadLine();
                Console.Write("Enter Date of Joining to be Updated: ");
                emp.DOJ = Convert.ToDateTime(Console.ReadLine());
                Console.Write("Enter Employee Salary to be Updated: ");
                emp.Salary = Convert.ToDouble(Console.ReadLine());

                bool empUpdated = EmployeeValidation.UpdateEmployee(emp);

                if (empUpdated)
                {
                    Console.WriteLine("Employee Updated Successfully");
                }
                else
                    throw new EmployeeException("Employee Details not Updated");

            }
            catch (EmployeeException ex)
            {
                Console.WriteLine(ex.Message);
            }
            catch (SystemException ex)
            {
                Console.WriteLine(ex.Message);
            }
        }

        public static void DeleteEmployee()
        {
            int id;

            try 
            {
                Console.Write("Enter Employee ID to be Deleted : ");
                id = Convert.ToInt32(Console.ReadLine());

                bool empdeleted = EmployeeValidation.DeleteEmployee(id);

                if (empdeleted)
                {
                    Console.WriteLine("Employee Deleted Successfully");
                }
                else
                    throw new EmployeeException("Employee not deleted");
            }
            catch (EmployeeException ex)
            {
                Console.WriteLine(ex.Message);
            }
            catch (SystemException ex)
            {
                Console.WriteLine(ex.Message);
            }
        }

        public static void SearchEmployee()
        {
            int id;
            Employee emp = null;

            try
            {
                Console.Write("Enter Employee ID to be Searched : ");
                id = Convert.ToInt32(Console.ReadLine());

                emp = EmployeeValidation.SearchEmployee(id);

                if (emp != null)
                {
                    Console.WriteLine("Employee ID : " + emp.ID);
                    Console.WriteLine("Employee Name : " + emp.Name);
                    Console.WriteLine("Date of Joining : " + emp.DOJ);
                    Console.WriteLine("Employee Salary : " + emp.Salary);
                }
                else
                    throw new EmployeeException("Employee not found");
            }
            catch (EmployeeException ex)
            {
                Console.WriteLine(ex.Message);
            }
            catch (SystemException ex)
            {
                Console.WriteLine(ex.Message);
            }
        }

        public static void RetrieveEmployees()
        {
            try
            {
                List<Employee> empList = EmployeeValidation.RetrieveEmployees();

                if (empList.Count > 0)
                {
                    Console.WriteLine("---------------------------------------------------------------------");
                    Console.WriteLine("Employee ID        Employee Name          Date of Joining    Salary");
                    Console.WriteLine("---------------------------------------------------------------------");
                    foreach (Employee emp in empList)
                    {
                        Console.WriteLine($"{emp.ID} \t {emp.Name} \t {emp.DOJ} \t {emp.Salary}");
                    }
                    Console.WriteLine("---------------------------------------------------------------------");
                }
                else
                {
                    throw new EmployeeException("Employee Details not Available");
                }
            }
            catch (EmployeeException ex)
            {
                Console.WriteLine(ex.Message);
            }
            catch (SystemException ex)
            {
                Console.WriteLine(ex.Message);
            }
        }

        public static void SerializeEmployee()
        {
            try
            {
                bool empSerialized = EmployeeValidation.SerializeEmployee();

                if (empSerialized)
                {
                    Console.WriteLine("Employee details serialized successfully");
                }
                else
                {
                    throw new EmployeeException("Employee Details not Serialized");
                }
            }
            catch (EmployeeException ex)
            {
                Console.WriteLine(ex.Message);
            }
            catch (SystemException ex)
            {
                Console.WriteLine(ex.Message);
            }
        }

        public static void DeserializeEmployees()
        {
            try
            {
                List<Employee> empList = EmployeeValidation.DeserializeEmployee();

                if (empList.Count > 0)
                {
                    Console.WriteLine("---------------------------------------------------------------------");
                    Console.WriteLine("Employee ID        Employee Name          Date of Joining    Salary");
                    Console.WriteLine("---------------------------------------------------------------------");
                    foreach (Employee emp in empList)
                    {
                        Console.WriteLine($"{emp.ID} \t {emp.Name} \t {emp.DOJ} \t {emp.Salary}");
                    }
                    Console.WriteLine("---------------------------------------------------------------------");
                }
                else
                {
                    throw new EmployeeException("Employee Details not Deserialized");
                }
            }
            catch (EmployeeException ex)
            {
                Console.WriteLine(ex.Message);
            }
            catch (SystemException ex)
            {
                Console.WriteLine(ex.Message);
            }
        }

        public static void PrintMenu()
        {
            Console.WriteLine("**************************");
            Console.WriteLine("1. Add Employee");
            Console.WriteLine("2. Update Employee");
            Console.WriteLine("3. Delete Employee");
            Console.WriteLine("4. Search Employee");
            Console.WriteLine("5. Retrieve Employee");
            Console.WriteLine("6. Serialize Employee");
            Console.WriteLine("7. Deserialize Employee");
            Console.WriteLine("8. Exit");
            Console.WriteLine("**************************");
        }

        static void Main(string[] args)
        {
            int choice;

            try
            {
                do
                {
                    PrintMenu();
                    Console.Write("Enter your choice : ");
                    choice = Convert.ToInt32(Console.ReadLine());
                    switch (choice)
                    {
                        case 1: AddEmployee();
                            break;
                        case 2: UpdateEmployee();
                            break;
                        case 3: DeleteEmployee();
                            break;
                        case 4: SearchEmployee();
                            break;
                        case 5: RetrieveEmployees();
                            break;
                        case 6: SerializeEmployee();
                            break;
                        case 7: DeserializeEmployees();
                            break;
                        case 8: Environment.Exit(0);
                            break;
                        default: Console.WriteLine("Please make valid choice");
                            break;
                    }
                } while (choice != 8);
            }
            catch (SystemException ex)
            {
                Console.WriteLine(ex.Message);
            }
        }
    }
}
