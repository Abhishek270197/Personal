﻿using System;

namespace EMS.Exception
{
    public class EmployeeException : ApplicationException
    {
        public EmployeeException() : base()
        { }

        public EmployeeException(string message) : base(message)
        { }
    }
}
